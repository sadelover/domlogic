// -*- c++ -*-
// ***********************************************************
//
// Copyright (C) 2013 R&B
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Module:   
// Author:   david
// Date:     2010/7/13
// Revision: 1.0
//
// ***********************************************************

#ifndef DBINTERFACEIMP_H
#define DBINTERFACEIMP_H

#include "../DllDefine.h"

#ifndef DBDLL
#define DBDLL DLLIMPORT
#endif


#endif