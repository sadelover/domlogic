
#pragma once
#ifndef DLLDEFILE_H
#define DLLDEFILE_H

#define DLLEXPORT _declspec(dllexport)
#define DLLIMPORT _declspec(dllimport)

#endif
