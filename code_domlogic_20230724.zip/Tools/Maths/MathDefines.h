#pragma once 
// #include "../NormalDefines.h"

#define M_E        2.71828182845904523536
