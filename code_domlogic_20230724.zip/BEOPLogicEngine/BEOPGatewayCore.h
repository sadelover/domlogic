#pragma once

#include "resource.h"
#include "XSTRING"

using namespace std;
