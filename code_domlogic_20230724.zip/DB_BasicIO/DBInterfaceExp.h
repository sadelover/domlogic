// -*- c++ -*-
// ***********************************************************
//
// Copyright (C) 2013 R&B
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Module:   
// Author:   david
// Date:     2010/7/13
// Revision: 1.0
//
// ***********************************************************

#ifndef DBINTERFACEEXP_H
#define DBINTERFACEEXP_H

#include "../Tools/DllDefine.h"

#define DBDLL DLLEXPORT

#endif